create schema db0;

use db0;

create table nonsense (`id` int unsigned not null auto_increment, `nonsense_a` longtext, `nonsense_b` longtext, `nonsense_c` longtext, primary key (`id`));
